# GENERATED VERSION FILE
# TIME: Sun Oct 18 21:58:53 2026
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
